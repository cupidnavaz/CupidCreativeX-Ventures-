
import { useState } from 'react';
import { MessageCircle, X, Maximize2, Minimize2 } from 'lucide-react';

export default function SupportAgent() {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-[9999]">
      {open && (
        <div
          className={`mb-4 overflow-hidden rounded-2xl bg-white shadow-2xl border border-gray-200 ${
            expanded
              ? 'fixed inset-3 sm:inset-6'
              : 'w-[min(390px,calc(100vw-32px))] h-[min(620px,calc(100dvh-110px))]'
          }`}
        >
          <div className="flex items-center justify-between bg-gray-950 text-white px-4 py-3">
            <div>
              <h3 className="font-semibold">Customer Support</h3>
              <p className="text-xs text-gray-300">
                AI Assistant
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setExpanded(!expanded)}
                aria-label={expanded ? 'Minimize chat' : 'Expand chat'}
              >
                {expanded ? <Minimize2 size={19} /> : <Maximize2 size={19} />}
              </button>

              <button
                onClick={() => setOpen(false)}
                aria-label="Close chat"
              >
                <X size={21} />
              </button>
            </div>
          </div>

          <iframe
            src="https://task-agentic.netlify.app/"
            title="Cupid Creative X AI Customer Support"
            className="w-full h-[calc(100%-56px)] border-0"
            allow="clipboard-write"
          />
        </div>
      )}

      <button
        onClick={() => setOpen(!open)}
        aria-label={open ? 'Close customer support' : 'Open customer support'}
        className="ml-auto flex h-16 w-16 items-center justify-center rounded-full bg-orange-500 text-white shadow-xl hover:bg-orange-600 transition-all hover:scale-105"
      >
        {open ? <X size={27} /> : <MessageCircle size={28} />}
      </button>
    </div>
  );
}
